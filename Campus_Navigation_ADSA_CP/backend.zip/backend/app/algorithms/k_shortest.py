import networkx as nx

def run_k_shortest(G, start, end, k=3):
    paths = list(nx.shortest_simple_paths(G, start, end, weight="weight"))

    result = []

    for p in paths[:k]:
        dist = sum(G[p[i]][p[i+1]]["weight"] for i in range(len(p)-1))

        result.append({
            "path": p,
            "distance": round(dist, 2)
        })

    return result